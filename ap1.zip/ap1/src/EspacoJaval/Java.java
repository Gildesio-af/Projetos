package EspacoJaval;

public class Java {
	ParOrdenado posicao = new ParOrdenado();
	public Java() {
		posicao.posicaoInicial(8, 8);
	}
}
