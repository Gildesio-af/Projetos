package EspacoJaval;

public interface Configuracao {
	public void configurar();
}
